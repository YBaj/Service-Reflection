import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    private TaskService taskService;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("1", "Test", "Description");
        taskService.addTask(task);
        assertEquals(task, taskService.getTask("1"));
    }

    @Test
    public void testAddDuplicateTask() {
        Task task1 = new Task("1", "Test1", "Description1");
        Task task2 = new Task("1", "Test2", "Description2");
        taskService.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(task2));
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("2", "Delete", "To be deleted");
        taskService.addTask(task);
        taskService.deleteTask("2");
        assertNull(taskService.getTask("2"));
    }

    @Test
    public void testDeleteNonExistentTask() {
        assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask("not-found"));
    }

    @Test
    public void testUpdateTaskName() {
        Task task = new Task("3", "Old Name", "Something");
        taskService.addTask(task);
        taskService.updateTaskName("3", "New Name");
        assertEquals("New Name", taskService.getTask("3").getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        Task task = new Task("4", "Name", "Old Description");
        taskService.addTask(task);
        taskService.updateTaskDescription("4", "New Description");
        assertEquals("New Description", taskService.getTask("4").getDescription());
    }