import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    private ContactService service;
    private Contact contact;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
        contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
    }

    @Test
    public void testAddContactDuplicate() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(new Contact("1", "Jane", "Doe", "0987654321", "456 Elm St"));
        });
    }

    @Test
    public void testDeleteContact() {
        service.deleteContact("1");
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("1"));
    }

    @Test
    public void testUpdateFirstName() {
        service.updateFirstName("1", "Jane");
        assertEquals("Jane", contact.getFirstName());
    }

    @Test
    public void testUpdateLastName() {
        service.updateLastName("1", "Smith");
        assertEquals("Smith", contact.getLastName());
    }

    @Test
    public void testUpdatePhone() {
        service.updatePhone("1", "0987654321");
        assertEquals("0987654321", contact.getPhone());
    }

    @Test
    public void testUpdateAddress() {
        service.updateAddress("1", "456 Elm St");
        assertEquals("456 Elm St", contact.getAddress());
    }

    @Test
    public void testUpdateNonExistentContact() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("999", "Jane");
        });
    }
}
