import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;
import java.util.Calendar;

public class AppointmentServiceTest {

    @Test
    public void testAddAndGetAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appt = new Appointment("B1", getFutureDate(), "Dental");
        service.addAppointment(appt);
        assertEquals(appt, service.getAppointment("B1"));
    }

    @Test
    public void testAddDuplicateId() {
        AppointmentService service = new AppointmentService();
        Appointment appt1 = new Appointment("B2", getFutureDate(), "Cleaning");
        Appointment appt2 = new Appointment("B2", getFutureDate(), "Follow-up");
        service.addAppointment(appt1);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appt2);
        });
    }

    @Test
    public void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appt = new Appointment("B3", getFutureDate(), "Eye Exam");
        service.addAppointment(appt);
        service.deleteAppointment("B3");
        assertNull(service.getAppointment("B3"));
    }

    @Test
    public void testDeleteNonexistentAppointment() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("B4");
        });
    }

    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);
        return cal.getTime();
    }
}
