import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;
import java.util.Calendar;

public class AppointmentTest {

    @Test
    public void testValidAppointment() {
        Date futureDate = getFutureDate();
        Appointment appt = new Appointment("A1", futureDate, "Checkup");
        assertEquals("A1", appt.getAppointmentId());
        assertEquals(futureDate, appt.getAppointmentDate());
        assertEquals("Checkup", appt.getDescription());
    }

    @Test
    public void testInvalidId() {
        Date futureDate = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Checkup");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("ThisIDIsTooLong", futureDate, "Checkup");
        });
    }

    @Test
    public void testInvalidDate() {
        Date pastDate = getPastDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A2", pastDate, "Past Date");
        });
    }

    @Test
    public void testInvalidDescription() {
        Date futureDate = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A3", futureDate, null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A3", futureDate, "This description is way too long and exceeds the allowed fifty characters.");
        });
    }

    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);
        return cal.getTime();
    }

    private Date getPastDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        return cal.getTime();
    }
}
