import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testValidTaskCreation() {
        Task task = new Task("12345", "My Task", "This is a task.");
        assertEquals("12345", task.getTaskId());
        assertEquals("My Task", task.getName());
        assertEquals("This is a task.", task.getDescription());
    }

    @Test
    public void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Test", "Desc");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Test", "Desc");
        });
    }

    @Test
    public void testInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", null, "Desc");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "This name is way too long for a task name", "Desc");
        });
    }

    @Test
    public void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "Name", null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "Name", "This description is way too long and should not be accepted because it is over fifty characters.");
        });
    }

    @Test
    public void testSetters() {
        Task task = new Task("001", "Initial", "Initial description");
        task.setName("Updated");
        task.setDescription("Updated description");
        assertEquals("Updated", task.getName());
        assertEquals("Updated description", task.getDescription());
    }
}