import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testValidContactCreation() {
        Contact c = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("12345", c.getContactId());
        assertEquals("John", c.getFirstName());
        assertEquals("Doe", c.getLastName());
        assertEquals("1234567890", c.getPhone());
        assertEquals("123 Main St", c.getAddress());
    }

    @Test
    public void testInvalidContactId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "John", "Doe", "1234567890", "123 Main St");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St");
        });
    }

    @Test
    public void testInvalidPhone() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "John", "Doe", "123", "123 Main St");
        });
    }

    @Test
    public void testSetters() {
        Contact c = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        c.setFirstName("Jane");
        assertEquals("Jane", c.getFirstName());

        c.setLastName("Smith");
        assertEquals("Smith", c.getLastName());

        c.setPhone("0987654321");
        assertEquals("0987654321", c.getPhone());

        c.setAddress("456 Elm St");
        assertEquals("456 Elm St", c.getAddress());

        assertThrows(IllegalArgumentException.class, () -> c.setPhone("1234"));
    }
}
